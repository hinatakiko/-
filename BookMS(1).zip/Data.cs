﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal class Data
    {
        //存储数据
        public static string UID = "", UName = "";//登录用户的id与姓名
    }
}
